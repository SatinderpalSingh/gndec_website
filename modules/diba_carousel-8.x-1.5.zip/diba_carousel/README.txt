= Diba carousel =

== Installation and configuration ==

Enable the module.
Go to: Administration > Estructure > Block layout.
Place a Diba carousel block in a region.
Configure the block settings.
