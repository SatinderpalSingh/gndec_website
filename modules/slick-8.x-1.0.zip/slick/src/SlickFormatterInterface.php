<?php

namespace Drupal\slick;

/**
 * Defines re-usable services and functions for slick field plugins.
 */
interface SlickFormatterInterface {}
