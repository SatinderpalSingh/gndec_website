Readme
------
This is a simple upload module. It popup a window that allows files/image to
be upload to a specific subdirectory in files (default files/public) and then
provide the html codes that people can cut-and-paste into their entry.

As it is uploaded into files, it can be managed by Drupal core system.

it also comes with a simple file manager.

For the current maintainer send information to James Seng <jseng@pobox.org.sg>

Note to Themer: 
  You may define how the popup windows looks like via theme_popup().

$Id: README.txt,v 1.1 2004/10/13 13:01:51 uwe Exp $
